-- MySQL dump 10.13  Distrib 5.5.31, for debian-linux-gnu (i686)
--
-- Host: localhost    Database: gitlabhq_production
-- ------------------------------------------------------
-- Server version	5.5.31-0+wheezy1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `deploy_keys_projects`
--

DROP TABLE IF EXISTS `deploy_keys_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deploy_keys_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `deploy_key_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_deploy_keys_projects_on_project_id` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deploy_keys_projects`
--

LOCK TABLES `deploy_keys_projects` WRITE;
/*!40000 ALTER TABLE `deploy_keys_projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `deploy_keys_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `target_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `target_id` int(11) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `project_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `action` int(11) DEFAULT NULL,
  `author_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_events_on_action` (`action`),
  KEY `index_events_on_author_id` (`author_id`),
  KEY `index_events_on_created_at` (`created_at`),
  KEY `index_events_on_project_id` (`project_id`),
  KEY `index_events_on_target_id` (`target_id`),
  KEY `index_events_on_target_type` (`target_type`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES (1,NULL,NULL,NULL,NULL,1,'2013-08-14 14:28:41','2013-08-14 14:28:41',8,1),(2,NULL,NULL,NULL,NULL,2,'2013-08-14 14:28:50','2013-08-14 14:28:50',8,1),(4,NULL,NULL,NULL,'---\n:before: \'0000000000000000000000000000000000000000\'\n:after: 3f1a3ec95f9919200a389910a72d8b990b4c6e88\n:ref: refs/heads/gl-pages\n:user_id: 1\n:user_name: Administrator\n:repository:\n  :name: first\n  :url: git@labpages:root/first.git\n  :description: \'\'\n  :homepage: http://labpages/root/first\n:commits: []\n:total_commits_count: 0\n',1,'2013-08-14 14:35:29','2013-08-14 14:35:29',5,1),(5,NULL,NULL,NULL,'---\n:before: \'0000000000000000000000000000000000000000\'\n:after: 1053583297022c0d6efc76284c551607a37b2a41\n:ref: refs/heads/master\n:user_id: 1\n:user_name: Administrator\n:repository:\n  :name: first\n  :url: git@labpages:root/first.git\n  :description: \'\'\n  :homepage: http://labpages/root/first\n:commits: []\n:total_commits_count: 0\n',1,'2013-08-14 14:35:54','2013-08-14 14:35:54',5,1),(6,NULL,NULL,NULL,'---\n:before: 3f1a3ec95f9919200a389910a72d8b990b4c6e88\n:after: 621e83aa2d63b1c8181f2234bd5fb55cc27f6e37\n:ref: refs/heads/gl-pages\n:user_id: 1\n:user_name: Administrator\n:repository:\n  :name: first\n  :url: git@labpages:root/first.git\n  :description: \'\'\n  :homepage: http://labpages/root/first\n:commits:\n- :id: !binary |-\n    NjIxZTgzYWEyZDYzYjFjODE4MWYyMjM0YmQ1ZmI1NWNjMjdmNmUzNw==\n  :message: Clean index\n  :timestamp: \'2013-08-14T16:39:52+02:00\'\n  :url: http://labpages/root/first/commit/621e83aa2d63b1c8181f2234bd5fb55cc27f6e37\n  :author:\n    :name: Vagrant\n    :email: vagrant@labpages\n:total_commits_count: 1\n',1,'2013-08-14 14:39:59','2013-08-14 14:39:59',5,1),(7,NULL,NULL,NULL,NULL,4,'2013-08-14 14:53:49','2013-08-14 14:53:49',8,1),(8,NULL,NULL,NULL,'---\n:before: \'0000000000000000000000000000000000000000\'\n:after: 621e83aa2d63b1c8181f2234bd5fb55cc27f6e37\n:ref: refs/heads/gl-pages\n:user_id: 1\n:user_name: Administrator\n:repository:\n  :name: root.labpages\n  :url: git@labpages:root/root-labpages.git\n  :description: \'\'\n  :homepage: http://labpages/root/root-labpages\n:commits: []\n:total_commits_count: 0\n',4,'2013-08-14 14:57:41','2013-08-14 14:57:41',5,1),(9,NULL,NULL,NULL,'---\n:before: 621e83aa2d63b1c8181f2234bd5fb55cc27f6e37\n:after: 48bfe7e85783940a5d3eaa0c08d735745cef1292\n:ref: refs/heads/gl-pages\n:user_id: 1\n:user_name: Administrator\n:repository:\n  :name: root.labpages\n  :url: git@labpages:root/root-labpages.git\n  :description: \'\'\n  :homepage: http://labpages/root/root-labpages\n:commits:\n- :id: !binary |-\n    NDhiZmU3ZTg1NzgzOTQwYTVkM2VhYTBjMDhkNzM1NzQ1Y2VmMTI5Mg==\n  :message: Fix index\n  :timestamp: \'2013-08-14T17:10:49+02:00\'\n  :url: http://labpages/root/root-labpages/commit/48bfe7e85783940a5d3eaa0c08d735745cef1292\n  :author:\n    :name: Vagrant\n    :email: vagrant@labpages\n:total_commits_count: 1\n',4,'2013-08-14 15:10:56','2013-08-14 15:10:56',5,1),(10,NULL,NULL,NULL,'---\n:before: \'0000000000000000000000000000000000000000\'\n:after: 621e83aa2d63b1c8181f2234bd5fb55cc27f6e37\n:ref: refs/heads/gl-pages\n:user_id: 1\n:user_name: Administrator\n:repository:\n  :name: labpages.labpages\n  :url: git@labpages:labpages/labpages-labpages.git\n  :description: \'\'\n  :homepage: http://labpages/labpages/labpages-labpages\n:commits: []\n:total_commits_count: 0\n',5,'2013-08-14 15:47:47','2013-08-14 15:47:47',5,1),(11,NULL,NULL,NULL,'---\n:before: 621e83aa2d63b1c8181f2234bd5fb55cc27f6e37\n:after: 77e265ec1a228dd826cc2a13efdd56c51cf800f1\n:ref: refs/heads/gl-pages\n:user_id: 1\n:user_name: Administrator\n:repository:\n  :name: labpages.labpages\n  :url: git@labpages:labpages/labpages-labpages.git\n  :description: \'\'\n  :homepage: http://labpages/labpages/labpages-labpages\n:commits:\n- :id: !binary |-\n    NzdlMjY1ZWMxYTIyOGRkODI2Y2MyYTEzZWZkZDU2YzUxY2Y4MDBmMQ==\n  :message: Update index\n  :timestamp: \'2013-08-14T17:49:19+02:00\'\n  :url: http://labpages/labpages/labpages-labpages/commit/77e265ec1a228dd826cc2a13efdd56c51cf800f1\n  :author:\n    :name: Vagrant\n    :email: vagrant@labpages\n:total_commits_count: 1\n',5,'2013-08-14 15:49:24','2013-08-14 15:49:24',5,1),(12,NULL,NULL,NULL,'---\n:before: \'0000000000000000000000000000000000000000\'\n:after: 621e83aa2d63b1c8181f2234bd5fb55cc27f6e37\n:ref: refs/heads/gl-pages\n:user_id: 1\n:user_name: Administrator\n:repository:\n  :name: second\n  :url: git@labpages:root/second.git\n  :description: \'\'\n  :homepage: http://labpages/root/second\n:commits: []\n:total_commits_count: 0\n',2,'2013-08-14 16:05:33','2013-08-14 16:05:33',5,1),(13,NULL,NULL,NULL,'---\n:before: 621e83aa2d63b1c8181f2234bd5fb55cc27f6e37\n:after: e3028b63774c70ed51008dbb67063a0821c2dee2\n:ref: refs/heads/gl-pages\n:user_id: 1\n:user_name: Administrator\n:repository:\n  :name: second\n  :url: git@labpages:root/second.git\n  :description: \'\'\n  :homepage: http://labpages/root/second\n:commits:\n- :id: !binary |-\n    ZTMwMjhiNjM3NzRjNzBlZDUxMDA4ZGJiNjcwNjNhMDgyMWMyZGVlMg==\n  :message: Clean index\n  :timestamp: \'2013-08-14T18:07:19+02:00\'\n  :url: http://labpages/root/second/commit/e3028b63774c70ed51008dbb67063a0821c2dee2\n  :author:\n    :name: Vagrant\n    :email: vagrant@labpages\n:total_commits_count: 1\n',2,'2013-08-14 16:07:31','2013-08-14 16:07:31',5,1),(14,NULL,NULL,NULL,'---\n:before: e3028b63774c70ed51008dbb67063a0821c2dee2\n:after: 44baa2420b6c4ab708120f296e6e61bd8f32cdcb\n:ref: refs/heads/gl-pages\n:user_id: 1\n:user_name: Administrator\n:repository:\n  :name: second\n  :url: git@labpages:root/second.git\n  :description: \'\'\n  :homepage: http://labpages/root/second\n:commits:\n- :id: !binary |-\n    NDRiYWEyNDIwYjZjNGFiNzA4MTIwZjI5NmU2ZTYxYmQ4ZjMyY2RjYg==\n  :message: Clean index\n  :timestamp: \'2013-08-14T18:09:39+02:00\'\n  :url: http://labpages/root/second/commit/44baa2420b6c4ab708120f296e6e61bd8f32cdcb\n  :author:\n    :name: Vagrant\n    :email: vagrant@labpages\n:total_commits_count: 1\n',2,'2013-08-14 16:09:47','2013-08-14 16:09:47',5,1),(15,NULL,NULL,NULL,'---\n:before: 44baa2420b6c4ab708120f296e6e61bd8f32cdcb\n:after: b7f7a469329574afcc8f91403f79c77a6c08eafe\n:ref: refs/heads/gl-pages\n:user_id: 1\n:user_name: Administrator\n:repository:\n  :name: second\n  :url: git@labpages:root/second.git\n  :description: \'\'\n  :homepage: http://labpages/root/second\n:commits:\n- :id: !binary |-\n    YjdmN2E0NjkzMjk1NzRhZmNjOGY5MTQwM2Y3OWM3N2E2YzA4ZWFmZQ==\n  :message: Clean index\n  :timestamp: \'2013-08-14T18:10:44+02:00\'\n  :url: http://labpages/root/second/commit/b7f7a469329574afcc8f91403f79c77a6c08eafe\n  :author:\n    :name: Vagrant\n    :email: vagrant@labpages\n:total_commits_count: 1\n',2,'2013-08-14 16:10:52','2013-08-14 16:10:52',5,1),(16,NULL,NULL,NULL,'---\n:before: 621e83aa2d63b1c8181f2234bd5fb55cc27f6e37\n:after: 7a847d61d639304d7f8e6a57223e554c1cb645f4\n:ref: refs/heads/gl-pages\n:user_id: 1\n:user_name: Administrator\n:repository:\n  :name: first\n  :url: git@labpages:root/first.git\n  :description: \'\'\n  :homepage: http://labpages/root/first\n:commits:\n- :id: !binary |-\n    N2E4NDdkNjFkNjM5MzA0ZDdmOGU2YTU3MjIzZTU1NGMxY2I2NDVmNA==\n  :message: Typo\n  :timestamp: \'2013-08-14T18:11:45+02:00\'\n  :url: http://labpages/root/first/commit/7a847d61d639304d7f8e6a57223e554c1cb645f4\n  :author:\n    :name: Vagrant\n    :email: vagrant@labpages\n:total_commits_count: 1\n',1,'2013-08-14 16:11:49','2013-08-14 16:11:49',5,1),(21,NULL,NULL,NULL,'---\n:before: 7a847d61d639304d7f8e6a57223e554c1cb645f4\n:after: 325cbcd550a204e1d636bd9a0162590f4c0450ce\n:ref: refs/heads/gl-pages\n:user_id: 1\n:user_name: Administrator\n:repository:\n  :name: first\n  :url: git@labpages:root/first.git\n  :description: \'\'\n  :homepage: http://labpages/root/first\n:commits:\n- :id: !binary |-\n    ZTM0ODI0MGM2NmNiNmFiNjYwZWQ4YmMyMDY4OGZhYjBiZTJkODk1Yg==\n  :message: Dummy\n  :timestamp: \'2013-08-14T18:21:25+02:00\'\n  :url: http://labpages/root/first/commit/e348240c66cb6ab660ed8bc20688fab0be2d895b\n  :author:\n    :name: Vagrant\n    :email: vagrant@labpages\n- :id: !binary |-\n    NjQyNmE1YTRjYTY0NGM5ODIwMzRlODk2ZWE0N2RkMDM3MDlmOWZmMg==\n  :message: Another dummy\n  :timestamp: \'2013-08-14T18:21:54+02:00\'\n  :url: http://labpages/root/first/commit/6426a5a4ca644c982034e896ea47dd03709f9ff2\n  :author:\n    :name: Vagrant\n    :email: vagrant@labpages\n- :id: !binary |-\n    MzI1Y2JjZDU1MGEyMDRlMWQ2MzZiZDlhMDE2MjU5MGY0YzA0NTBjZQ==\n  :message: Another empty commit\n  :timestamp: \'2013-08-14T18:22:14+02:00\'\n  :url: http://labpages/root/first/commit/325cbcd550a204e1d636bd9a0162590f4c0450ce\n  :author:\n    :name: Vagrant\n    :email: vagrant@labpages\n:total_commits_count: 3\n',1,'2013-08-14 16:22:19','2013-08-14 16:22:19',5,1),(23,NULL,NULL,NULL,NULL,6,'2013-08-14 17:59:42','2013-08-14 17:59:42',8,1),(24,NULL,NULL,NULL,'---\n:before: \'0000000000000000000000000000000000000000\'\n:after: b7f7a469329574afcc8f91403f79c77a6c08eafe\n:ref: refs/heads/gl-pages\n:user_id: 1\n:user_name: Administrator\n:repository:\n  :name: third\n  :url: git@labpages:root/third.git\n  :description: \'\'\n  :homepage: http://labpages/root/third\n:commits: []\n:total_commits_count: 0\n',6,'2013-08-14 17:59:55','2013-08-14 17:59:55',5,1),(25,NULL,NULL,NULL,'---\n:before: b7f7a469329574afcc8f91403f79c77a6c08eafe\n:after: 6ac6a19f54f6391205d7a1dd925ce74c2dc1d751\n:ref: refs/heads/gl-pages\n:user_id: 1\n:user_name: Administrator\n:repository:\n  :name: third\n  :url: git@labpages:root/third.git\n  :description: \'\'\n  :homepage: http://labpages/root/third\n:commits:\n- :id: !binary |-\n    NmFjNmExOWY1NGY2MzkxMjA1ZDdhMWRkOTI1Y2U3NGMyZGMxZDc1MQ==\n  :message: Update index\n  :timestamp: \'2013-08-14T20:05:22+02:00\'\n  :url: http://labpages/root/third/commit/6ac6a19f54f6391205d7a1dd925ce74c2dc1d751\n  :author:\n    :name: Vagrant\n    :email: vagrant@labpages\n:total_commits_count: 1\n',6,'2013-08-14 18:05:26','2013-08-14 18:05:26',5,1),(26,NULL,NULL,NULL,'---\n:before: 77e265ec1a228dd826cc2a13efdd56c51cf800f1\n:after: 02e93701aa76e152ff5e9c477fd53c5c6ee7d129\n:ref: refs/heads/gl-pages\n:user_id: 1\n:user_name: Administrator\n:repository:\n  :name: labpages.labpages\n  :url: git@labpages:labpages/labpages-labpages.git\n  :description: \'\'\n  :homepage: http://labpages/labpages/labpages-labpages\n:commits:\n- :id: !binary |-\n    MDJlOTM3MDFhYTc2ZTE1MmZmNWU5YzQ3N2ZkNTNjNWM2ZWU3ZDEyOQ==\n  :message: Update index\n  :timestamp: \'2013-08-14T20:09:26+02:00\'\n  :url: http://labpages/labpages/labpages-labpages/commit/02e93701aa76e152ff5e9c477fd53c5c6ee7d129\n  :author:\n    :name: Vagrant\n    :email: vagrant@labpages\n:total_commits_count: 1\n',5,'2013-08-14 18:09:34','2013-08-14 18:09:34',5,1),(27,NULL,NULL,NULL,'---\n:before: 48bfe7e85783940a5d3eaa0c08d735745cef1292\n:after: 57569a5ed9efa373ff02d861609828b17a961308\n:ref: refs/heads/gl-pages\n:user_id: 1\n:user_name: Administrator\n:repository:\n  :name: root.labpages\n  :url: git@labpages:root/root-labpages.git\n  :description: \'\'\n  :homepage: http://labpages/root/root-labpages\n:commits:\n- :id: !binary |-\n    NTc1NjlhNWVkOWVmYTM3M2ZmMDJkODYxNjA5ODI4YjE3YTk2MTMwOA==\n  :message: Fix index\n  :timestamp: \'2013-08-14T20:10:21+02:00\'\n  :url: http://labpages/root/root-labpages/commit/57569a5ed9efa373ff02d861609828b17a961308\n  :author:\n    :name: Vagrant\n    :email: vagrant@labpages\n:total_commits_count: 1\n',4,'2013-08-14 18:10:27','2013-08-14 18:10:27',5,1),(28,NULL,NULL,NULL,NULL,7,'2013-08-14 19:13:16','2013-08-14 19:13:16',8,1),(29,NULL,NULL,NULL,'---\n:before: \'0000000000000000000000000000000000000000\'\n:after: a9ed70d1c49e2013868733c73d0a4de87386e6f3\n:ref: refs/heads/gl-pages\n:user_id: 1\n:user_name: Administrator\n:repository:\n  :name: jekyll\n  :url: git@labpages:root/jekyll.git\n  :description: \'\'\n  :homepage: http://labpages/root/jekyll\n:commits: []\n:total_commits_count: 0\n',7,'2013-08-14 19:16:29','2013-08-14 19:16:29',5,1),(30,NULL,NULL,NULL,'---\n:before: a9ed70d1c49e2013868733c73d0a4de87386e6f3\n:after: d70de147e0d4d2d9b41490d812c177293c543b25\n:ref: refs/heads/gl-pages\n:user_id: 1\n:user_name: Administrator\n:repository:\n  :name: jekyll\n  :url: git@labpages:root/jekyll.git\n  :description: \'\'\n  :homepage: http://labpages/root/jekyll\n:commits:\n- :id: !binary |-\n    ZDcwZGUxNDdlMGQ0ZDJkOWI0MTQ5MGQ4MTJjMTc3MjkzYzU0M2IyNQ==\n  :message: Remove CNAME\n  :timestamp: \'2013-08-14T21:17:55+02:00\'\n  :url: http://labpages/root/jekyll/commit/d70de147e0d4d2d9b41490d812c177293c543b25\n  :author:\n    :name: Vagrant\n    :email: vagrant@labpages\n:total_commits_count: 1\n',7,'2013-08-14 19:18:02','2013-08-14 19:18:02',5,1),(31,NULL,NULL,NULL,'---\n:before: d70de147e0d4d2d9b41490d812c177293c543b25\n:after: 8adb3e19a7bbc36821fe221f91c2e524f3c2d49e\n:ref: refs/heads/gl-pages\n:user_id: 1\n:user_name: Administrator\n:repository:\n  :name: jekyll\n  :url: git@labpages:root/jekyll.git\n  :description: \'\'\n  :homepage: http://labpages/root/jekyll\n:commits:\n- :id: !binary |-\n    OGFkYjNlMTlhN2JiYzM2ODIxZmUyMjFmOTFjMmU1MjRmM2MyZDQ5ZQ==\n  :message: Fix config\n  :timestamp: \'2013-08-14T21:30:38+02:00\'\n  :url: http://labpages/root/jekyll/commit/8adb3e19a7bbc36821fe221f91c2e524f3c2d49e\n  :author:\n    :name: Vagrant\n    :email: vagrant@labpages\n:total_commits_count: 1\n',7,'2013-08-14 19:30:41','2013-08-14 19:30:41',5,1),(32,NULL,NULL,NULL,'---\n:before: 8adb3e19a7bbc36821fe221f91c2e524f3c2d49e\n:after: f302e2784130530842cb367f03ca838feac14264\n:ref: refs/heads/gl-pages\n:user_id: 1\n:user_name: Administrator\n:repository:\n  :name: jekyll\n  :url: git@labpages:root/jekyll.git\n  :description: \'\'\n  :homepage: http://labpages/root/jekyll\n:commits:\n- :id: !binary |-\n    ZjMwMmUyNzg0MTMwNTMwODQyY2IzNjdmMDNjYTgzOGZlYWMxNDI2NA==\n  :message: Add labpage base url\n  :timestamp: \'2013-08-14T21:41:04+02:00\'\n  :url: http://labpages/root/jekyll/commit/f302e2784130530842cb367f03ca838feac14264\n  :author:\n    :name: Vagrant\n    :email: vagrant@labpages\n:total_commits_count: 1\n',7,'2013-08-14 19:41:07','2013-08-14 19:41:07',5,1),(33,NULL,NULL,NULL,'---\n:before: f302e2784130530842cb367f03ca838feac14264\n:after: 83dd9de64685a9799bec661d46d73720c6ea34ca\n:ref: refs/heads/gl-pages\n:user_id: 1\n:user_name: Administrator\n:repository:\n  :name: jekyll\n  :url: git@labpages:root/jekyll.git\n  :description: \'\'\n  :homepage: http://labpages/root/jekyll\n:commits:\n- :id: !binary |-\n    ODNkZDlkZTY0Njg1YTk3OTliZWM2NjFkNDZkNzM3MjBjNmVhMzRjYQ==\n  :message: Fix links on index\n  :timestamp: \'2013-08-14T21:58:47+02:00\'\n  :url: http://labpages/root/jekyll/commit/83dd9de64685a9799bec661d46d73720c6ea34ca\n  :author:\n    :name: Vagrant\n    :email: vagrant@labpages\n:total_commits_count: 1\n',7,'2013-08-14 19:58:50','2013-08-14 19:58:50',5,1);
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forked_project_links`
--

DROP TABLE IF EXISTS `forked_project_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forked_project_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `forked_to_project_id` int(11) NOT NULL,
  `forked_from_project_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_forked_project_links_on_forked_to_project_id` (`forked_to_project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forked_project_links`
--

LOCK TABLES `forked_project_links` WRITE;
/*!40000 ALTER TABLE `forked_project_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `forked_project_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issues`
--

DROP TABLE IF EXISTS `issues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `issues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `assignee_id` int(11) DEFAULT NULL,
  `author_id` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `position` int(11) DEFAULT '0',
  `branch_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `milestone_id` int(11) DEFAULT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_issues_on_assignee_id` (`assignee_id`),
  KEY `index_issues_on_author_id` (`author_id`),
  KEY `index_issues_on_created_at` (`created_at`),
  KEY `index_issues_on_milestone_id` (`milestone_id`),
  KEY `index_issues_on_project_id` (`project_id`),
  KEY `index_issues_on_title` (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issues`
--

LOCK TABLES `issues` WRITE;
/*!40000 ALTER TABLE `issues` DISABLE KEYS */;
/*!40000 ALTER TABLE `issues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `keys`
--

DROP TABLE IF EXISTS `keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `keys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `key` text COLLATE utf8_unicode_ci,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fingerprint` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_keys_on_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `keys`
--

LOCK TABLES `keys` WRITE;
/*!40000 ALTER TABLE `keys` DISABLE KEYS */;
INSERT INTO `keys` VALUES (1,1,'2013-08-14 14:29:55','2013-08-14 14:29:55','ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDbjkvV6AFHipSh/Nd/WvuoWLh7gZQIgOTlnT9hEiRP5TdhneVfNzZPfOcTKeAXDxa8b0N+3/GK+NBKwwueaOWvxi66rEe48gs06WCxKnHKyJ4ZUZGJ3kbzuEw2mQZDKPbIugEGkG6xS7Xic6emtIx692uu8xAxk4Llkcml4ogghRCl4t1peq5fK9GOhBN5vSsQ6/koGqtkhBYTyY2eF71KlKNDtWzwKQgqJla/v/+2bRulGcguRPlAgtU3WTCfds60bpToN493++mXuvja2SbvTl/uaPCKKjNolaUEX9iPW9R3C/esnP0PVDh8q70Fz0HNcN3NFEX7uFZENUtLcDiJ vagrant@labpages','vagrant@labpages',NULL,'02:21:8d:46:45:d9:76:b7:88:93:ea:e1:1a:c9:ca:d5');
/*!40000 ALTER TABLE `keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `merge_requests`
--

DROP TABLE IF EXISTS `merge_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `merge_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `target_branch` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `source_branch` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `source_project_id` int(11) NOT NULL,
  `author_id` int(11) DEFAULT NULL,
  `assignee_id` int(11) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `st_commits` longtext COLLATE utf8_unicode_ci,
  `st_diffs` longtext COLLATE utf8_unicode_ci,
  `milestone_id` int(11) DEFAULT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `merge_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `target_project_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_merge_requests_on_assignee_id` (`assignee_id`),
  KEY `index_merge_requests_on_author_id` (`author_id`),
  KEY `index_merge_requests_on_created_at` (`created_at`),
  KEY `index_merge_requests_on_milestone_id` (`milestone_id`),
  KEY `index_merge_requests_on_source_branch` (`source_branch`),
  KEY `index_merge_requests_on_project_id` (`source_project_id`),
  KEY `index_merge_requests_on_target_branch` (`target_branch`),
  KEY `index_merge_requests_on_title` (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `merge_requests`
--

LOCK TABLES `merge_requests` WRITE;
/*!40000 ALTER TABLE `merge_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `merge_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `milestones`
--

DROP TABLE IF EXISTS `milestones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `milestones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `project_id` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `due_date` date DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_milestones_on_due_date` (`due_date`),
  KEY `index_milestones_on_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `milestones`
--

LOCK TABLES `milestones` WRITE;
/*!40000 ALTER TABLE `milestones` DISABLE KEYS */;
/*!40000 ALTER TABLE `milestones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `namespaces`
--

DROP TABLE IF EXISTS `namespaces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `namespaces` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `owner_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `index_namespaces_on_name` (`name`),
  KEY `index_namespaces_on_owner_id` (`owner_id`),
  KEY `index_namespaces_on_path` (`path`),
  KEY `index_namespaces_on_type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `namespaces`
--

LOCK TABLES `namespaces` WRITE;
/*!40000 ALTER TABLE `namespaces` DISABLE KEYS */;
INSERT INTO `namespaces` VALUES (1,'Administrator','root',1,'2013-08-11 21:07:38','2013-08-11 21:07:38',NULL,''),(2,'labpages','labpages',1,'2013-08-14 14:49:02','2013-08-14 14:49:02','Group','');
/*!40000 ALTER TABLE `namespaces` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `note` text COLLATE utf8_unicode_ci,
  `noteable_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `author_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `project_id` int(11) DEFAULT NULL,
  `attachment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `line_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `commit_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `noteable_id` int(11) DEFAULT NULL,
  `st_diff` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `index_notes_on_author_id` (`author_id`),
  KEY `index_notes_on_commit_id` (`commit_id`),
  KEY `index_notes_on_created_at` (`created_at`),
  KEY `index_notes_on_noteable_id_and_noteable_type` (`noteable_id`,`noteable_type`),
  KEY `index_notes_on_noteable_type` (`noteable_type`),
  KEY `index_notes_on_project_id_and_noteable_type` (`project_id`,`noteable_type`),
  KEY `index_notes_on_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes`
--

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `creator_id` int(11) DEFAULT NULL,
  `default_branch` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `issues_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `wall_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `merge_requests_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `wiki_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `namespace_id` int(11) DEFAULT NULL,
  `public` tinyint(1) NOT NULL DEFAULT '0',
  `issues_tracker` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'gitlab',
  `issues_tracker_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `snippets_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `last_activity_at` datetime DEFAULT NULL,
  `imported` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `index_projects_on_owner_id` (`creator_id`),
  KEY `index_projects_on_last_activity_at` (`last_activity_at`),
  KEY `index_projects_on_namespace_id` (`namespace_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` VALUES (1,'first','first','','2013-08-14 14:28:41','2013-08-14 14:36:03',1,'master',1,0,1,1,1,0,'gitlab',NULL,0,'2013-08-14 16:22:19',0),(2,'second','second','','2013-08-14 14:28:50','2013-08-14 16:05:33',1,'gl-pages',1,0,1,1,1,0,'gitlab',NULL,0,'2013-08-14 16:10:52',0),(4,'root.labpages','root-labpages','','2013-08-14 14:53:49','2013-08-14 14:57:41',1,'gl-pages',1,0,1,1,1,0,'gitlab',NULL,0,'2013-08-14 18:10:27',0),(5,'labpages.labpages','labpages-labpages','','2013-08-14 15:46:32','2013-08-14 15:47:47',1,'gl-pages',1,0,1,1,2,0,'gitlab',NULL,0,'2013-08-14 18:09:34',0),(6,'third','third','','2013-08-14 17:59:42','2013-08-14 17:59:56',1,'gl-pages',1,0,1,1,1,0,'gitlab',NULL,0,'2013-08-14 18:05:26',0),(7,'jekyll','jekyll','','2013-08-14 19:13:16','2013-08-14 19:13:16',1,'master',1,0,1,1,1,0,'gitlab',NULL,0,'2013-08-14 19:58:50',1);
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `protected_branches`
--

DROP TABLE IF EXISTS `protected_branches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `protected_branches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_protected_branches_on_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `protected_branches`
--

LOCK TABLES `protected_branches` WRITE;
/*!40000 ALTER TABLE `protected_branches` DISABLE KEYS */;
/*!40000 ALTER TABLE `protected_branches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_migrations`
--

DROP TABLE IF EXISTS `schema_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schema_migrations` (
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  UNIQUE KEY `unique_schema_migrations` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_migrations`
--

LOCK TABLES `schema_migrations` WRITE;
/*!40000 ALTER TABLE `schema_migrations` DISABLE KEYS */;
INSERT INTO `schema_migrations` VALUES ('20110913200833'),('20110913204141'),('20110914221600'),('20110915205627'),('20110915213352'),('20110916123731'),('20110916162511'),('20110917212932'),('20110921192501'),('20110922110156'),('20110923211333'),('20110924214549'),('20110924215658'),('20110926082616'),('20110927130352'),('20110928140106'),('20110928142747'),('20110928161328'),('20111005193700'),('20111009101738'),('20111009110913'),('20111009111204'),('20111015154310'),('20111016183422'),('20111016193417'),('20111016195506'),('20111019212429'),('20111021101550'),('20111025134235'),('20111027051828'),('20111027142641'),('20111027152724'),('20111101222453'),('20111111093150'),('20111115063954'),('20111124115339'),('20111127155345'),('20111206213842'),('20111206222316'),('20111207211728'),('20111214091851'),('20111220190817'),('20111231111825'),('20120110180749'),('20120119202326'),('20120121122616'),('20120206170141'),('20120215182305'),('20120216085842'),('20120216215008'),('20120219130957'),('20120219140810'),('20120219193300'),('20120228130210'),('20120228134252'),('20120301185805'),('20120307095918'),('20120315111711'),('20120315132931'),('20120317095543'),('20120323221339'),('20120329170745'),('20120405211750'),('20120408180246'),('20120408181910'),('20120413135904'),('20120627145613'),('20120706065612'),('20120712080407'),('20120729131232'),('20120905043334'),('20121002150926'),('20121002151033'),('20121009205010'),('20121026114600'),('20121119170638'),('20121120051432'),('20121120103700'),('20121120113838'),('20121122145155'),('20121122150932'),('20121123104937'),('20121123164910'),('20121203154450'),('20121203160507'),('20121205201726'),('20121218164840'),('20121219095402'),('20121219183753'),('20121220064104'),('20121220064453'),('20130102143055'),('20130110172407'),('20130123114545'),('20130125090214'),('20130131070232'),('20130206084024'),('20130207104426'),('20130211085435'),('20130214154045'),('20130218140952'),('20130218141038'),('20130218141117'),('20130218141258'),('20130218141327'),('20130218141344'),('20130218141444'),('20130218141507'),('20130218141536'),('20130218141554'),('20130220124204'),('20130220125544'),('20130220125545'),('20130220133245'),('20130304104623'),('20130304104740'),('20130304105317'),('20130315124931'),('20130318212250'),('20130319214458'),('20130323174317'),('20130324151736'),('20130324172327'),('20130324203535'),('20130325173941'),('20130326142630'),('20130403003950'),('20130404164628'),('20130410175022'),('20130419190306'),('20130506085413'),('20130506090604'),('20130506095501'),('20130522141856'),('20130611210815'),('20130613165816'),('20130613173246'),('20130614132337'),('20130617095603'),('20130621195223'),('20130622115340'),('20130624162710'),('20130804151314');
/*!40000 ALTER TABLE `schema_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `project_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `project_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subdomain` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `room` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_services_on_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `snippets`
--

DROP TABLE IF EXISTS `snippets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `snippets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8_unicode_ci,
  `author_id` int(11) NOT NULL,
  `project_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `file_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `private` tinyint(1) NOT NULL DEFAULT '1',
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_snippets_on_author_id` (`author_id`),
  KEY `index_snippets_on_created_at` (`created_at`),
  KEY `index_snippets_on_expires_at` (`expires_at`),
  KEY `index_snippets_on_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `snippets`
--

LOCK TABLES `snippets` WRITE;
/*!40000 ALTER TABLE `snippets` DISABLE KEYS */;
/*!40000 ALTER TABLE `snippets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggings`
--

DROP TABLE IF EXISTS `taggings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taggings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tag_id` int(11) DEFAULT NULL,
  `taggable_id` int(11) DEFAULT NULL,
  `taggable_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tagger_id` int(11) DEFAULT NULL,
  `tagger_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `context` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_taggings_on_tag_id` (`tag_id`),
  KEY `index_taggings_on_taggable_id_and_taggable_type_and_context` (`taggable_id`,`taggable_type`,`context`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taggings`
--

LOCK TABLES `taggings` WRITE;
/*!40000 ALTER TABLE `taggings` DISABLE KEYS */;
/*!40000 ALTER TABLE `taggings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_team_project_relationships`
--

DROP TABLE IF EXISTS `user_team_project_relationships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_team_project_relationships` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT NULL,
  `user_team_id` int(11) DEFAULT NULL,
  `greatest_access` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_team_project_relationships`
--

LOCK TABLES `user_team_project_relationships` WRITE;
/*!40000 ALTER TABLE `user_team_project_relationships` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_team_project_relationships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_team_user_relationships`
--

DROP TABLE IF EXISTS `user_team_user_relationships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_team_user_relationships` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `user_team_id` int(11) DEFAULT NULL,
  `group_admin` tinyint(1) DEFAULT NULL,
  `permission` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_team_user_relationships`
--

LOCK TABLES `user_team_user_relationships` WRITE;
/*!40000 ALTER TABLE `user_team_user_relationships` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_team_user_relationships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_teams`
--

DROP TABLE IF EXISTS `user_teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_teams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_teams`
--

LOCK TABLES `user_teams` WRITE;
/*!40000 ALTER TABLE `user_teams` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `encrypted_password` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `reset_password_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reset_password_sent_at` datetime DEFAULT NULL,
  `remember_created_at` datetime DEFAULT NULL,
  `sign_in_count` int(11) DEFAULT '0',
  `current_sign_in_at` datetime DEFAULT NULL,
  `last_sign_in_at` datetime DEFAULT NULL,
  `current_sign_in_ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_sign_in_ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `projects_limit` int(11) DEFAULT '10',
  `skype` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `linkedin` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `twitter` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `authentication_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `theme_id` int(11) NOT NULL DEFAULT '1',
  `bio` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `failed_attempts` int(11) DEFAULT '0',
  `locked_at` datetime DEFAULT NULL,
  `extern_uid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `provider` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `can_create_group` tinyint(1) NOT NULL DEFAULT '1',
  `can_create_team` tinyint(1) NOT NULL DEFAULT '1',
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `color_scheme_id` int(11) NOT NULL DEFAULT '1',
  `notification_level` int(11) NOT NULL DEFAULT '1',
  `password_expires_at` datetime DEFAULT NULL,
  `created_by_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_users_on_email` (`email`),
  UNIQUE KEY `index_users_on_authentication_token` (`authentication_token`),
  UNIQUE KEY `index_users_on_extern_uid_and_provider` (`extern_uid`,`provider`),
  UNIQUE KEY `index_users_on_reset_password_token` (`reset_password_token`),
  KEY `index_users_on_admin` (`admin`),
  KEY `index_users_on_name` (`name`),
  KEY `index_users_on_username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin@local.host','$2a$10$.VYP6L4pc6/7.0Wc8uHVceylNyjNBLhgVyWokKJsa7w0csBlek5.C',NULL,NULL,NULL,2,'2013-08-11 21:36:07','2013-08-11 21:35:53',NULL,NULL,'2013-08-11 21:07:38','2013-08-11 21:36:07','Administrator',1,10000,'','','','Act65b4s8ekraaxocxxo',1,NULL,0,NULL,NULL,NULL,'root',1,1,'active',1,1,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_groups`
--

DROP TABLE IF EXISTS `users_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_access` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `notification_level` int(11) NOT NULL DEFAULT '3',
  PRIMARY KEY (`id`),
  KEY `index_users_groups_on_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_groups`
--

LOCK TABLES `users_groups` WRITE;
/*!40000 ALTER TABLE `users_groups` DISABLE KEYS */;
INSERT INTO `users_groups` VALUES (1,50,2,1,'2013-08-14 14:49:02','2013-08-14 14:49:02',3);
/*!40000 ALTER TABLE `users_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_projects`
--

DROP TABLE IF EXISTS `users_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `project_access` int(11) NOT NULL DEFAULT '0',
  `notification_level` int(11) NOT NULL DEFAULT '3',
  PRIMARY KEY (`id`),
  KEY `index_users_projects_on_project_access` (`project_access`),
  KEY `index_users_projects_on_project_id` (`project_id`),
  KEY `index_users_projects_on_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_projects`
--

LOCK TABLES `users_projects` WRITE;
/*!40000 ALTER TABLE `users_projects` DISABLE KEYS */;
INSERT INTO `users_projects` VALUES (1,1,1,'2013-08-14 14:28:41','2013-08-14 14:28:41',40,3),(2,1,2,'2013-08-14 14:28:50','2013-08-14 14:28:50',40,3),(4,1,4,'2013-08-14 14:53:49','2013-08-14 14:53:49',40,3),(5,1,6,'2013-08-14 17:59:42','2013-08-14 17:59:42',40,3),(6,1,7,'2013-08-14 19:13:16','2013-08-14 19:13:16',40,3);
/*!40000 ALTER TABLE `users_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `web_hooks`
--

DROP TABLE IF EXISTS `web_hooks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `web_hooks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'ProjectHook',
  `service_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_web_hooks_on_project_id` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `web_hooks`
--

LOCK TABLES `web_hooks` WRITE;
/*!40000 ALTER TABLE `web_hooks` DISABLE KEYS */;
INSERT INTO `web_hooks` VALUES (2,'http://pages.labpages/hook/gitlab',4,'2013-08-14 14:54:40','2013-08-14 14:54:40','ProjectHook',NULL),(3,'http://requestb.in/1eqvazf1',4,'2013-08-14 15:08:29','2013-08-14 15:08:29','ProjectHook',NULL),(4,'http://pages.labpages/hook/gitlab',5,'2013-08-14 15:48:20','2013-08-14 15:48:20','ProjectHook',NULL),(6,'http://pages.labpages/hook/gitlab',2,'2013-08-14 16:10:12','2013-08-14 16:10:12','ProjectHook',NULL),(7,'http://pages.labpages/hook/gitlab',6,'2013-08-14 17:59:50','2013-08-14 17:59:50','ProjectHook',NULL),(8,'http://pages.labpages/hook/gitlab',7,'2013-08-14 19:16:38','2013-08-14 19:16:38','ProjectHook',NULL);
/*!40000 ALTER TABLE `web_hooks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-08-14 22:00:31
